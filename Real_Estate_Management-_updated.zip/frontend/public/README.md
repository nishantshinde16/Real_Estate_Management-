Public assets
