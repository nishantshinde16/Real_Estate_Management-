import { useEffect, useState } from 'react';
import ImageUpload from '../ImageUpload';

const initialState = {
  title: '',
  description: '',
  location: '',
  price: '',
  propertyType: 'Apartment',
  bedrooms: 1,
  bathrooms: 1,
  area: '',
  image: '',
};

const propertyTypes = ['Apartment', 'Villa', 'House', 'Plot', 'Commercial'];
const emptyInitialValues = {};

function PropertyForm({ initialValues = emptyInitialValues, onSubmit, submitLabel = 'Save Property', isEdit = false }) {
  const [form, setForm] = useState({ ...initialState, ...initialValues });
  const [images, setImages] = useState([]);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    setForm({ ...initialState, ...initialValues });
    setImages([]);
  }, [initialValues]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  };

  const validate = () => {
    const nextErrors = {};
    if (!form.title.trim()) nextErrors.title = 'Property title is required.';
    if (!form.description.trim()) nextErrors.description = 'Description is required.';
    if (!form.location.trim()) nextErrors.location = 'Location is required.';
    if (!form.price || Number(form.price) <= 0) nextErrors.price = 'Enter a valid price.';
    if (!form.area || Number(form.area) <= 0) nextErrors.area = 'Enter the area in square feet.';
    if (Number(form.bedrooms) < 0) nextErrors.bedrooms = 'Bedrooms cannot be negative.';
    if (Number(form.bathrooms) < 0) nextErrors.bathrooms = 'Bathrooms cannot be negative.';
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    const payload = new FormData();
    Object.entries(form).forEach(([key, value]) => {
      if (key !== 'image') payload.append(key, value);
    });
    if (images[0]) payload.append('image', images[0]);
    onSubmit(payload);
  };

  return (
    <form className="form-grid" onSubmit={handleSubmit}>
      <label>Property Title<input name="title" placeholder="Property title" value={form.title} onChange={handleChange} required /></label>
      <label>Location<input name="location" placeholder="Location" value={form.location} onChange={handleChange} required /></label>
      {errors.title && <p className="error">{errors.title}</p>}
      <label>Price<input name="price" type="number" min="1" placeholder="Price" value={form.price} onChange={handleChange} required /></label>
      <label>Category<select name="propertyType" value={form.propertyType} onChange={handleChange}>{propertyTypes.map((type) => <option key={type}>{type}</option>)}</select></label>
      {errors.price && <p className="error">{errors.price}</p>}
      <label>Bedrooms<input name="bedrooms" type="number" min="0" placeholder="Bedrooms" value={form.bedrooms} onChange={handleChange} /></label>
      <label>Bathrooms<input name="bathrooms" type="number" min="0" placeholder="Bathrooms" value={form.bathrooms} onChange={handleChange} /></label>
      <label>Area<input name="area" type="number" min="1" placeholder="Area in sq ft" value={form.area} onChange={handleChange} required /></label>
      <label>Description<textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} required /></label>
      {(errors.description || errors.area || errors.bedrooms || errors.bathrooms) && (
        <p className="error">{errors.description || errors.area || errors.bedrooms || errors.bathrooms}</p>
      )}
      <ImageUpload existingImage={isEdit ? form.image : ''} images={images} onChange={setImages} />
      <button className="btn" type="submit">{submitLabel}</button>
    </form>
  );
}

export default PropertyForm;
