import { useNavigate } from 'react-router-dom';
import PropertyForm from '../../components/ui/PropertyForm';
import { createProperty } from '../../services/propertyService';

function AddProperty() {
  const navigate = useNavigate();

  const submit = async (payload) => {
    await createProperty(payload);
    navigate('/admin/properties');
  };

  return (
    <section className="section admin-page">
      <div className="section-heading">
        <div>
          <p className="eyebrow">Admin Panel</p>
          <h1>Add Property</h1>
        </div>
      </div>
      <PropertyForm onSubmit={submit} submitLabel="Add Property" />
    </section>
  );
}

export default AddProperty;
