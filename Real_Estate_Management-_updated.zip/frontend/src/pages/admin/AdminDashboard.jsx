import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getBookings } from '../../services/bookingService';
import { getAllInquiries } from '../../services/inquiryService';
import { getLeads } from '../../services/leadService';
import { getProperties } from '../../services/propertyService';
import { getAdminStats, getUsers } from '../../services/userService';
import { formatPrice } from '../../utils/format';

function AdminDashboard() {
  const [stats, setStats] = useState({ users: 0, properties: 0, inquiries: 0 });
  const [users, setUsers] = useState([]);
  const [properties, setProperties] = useState([]);
  const [inquiries, setInquiries] = useState([]);
  const [leads, setLeads] = useState([]);
  const [bookings, setBookings] = useState([]);

  const load = async () => {
    const [statsRes, usersRes, propertiesRes, inquiriesRes, leadsRes, bookingsRes] = await Promise.all([
      getAdminStats(),
      getUsers(),
      getProperties(),
      getAllInquiries(),
      getLeads(),
      getBookings(),
    ]);
    setStats(statsRes.data);
    setUsers(usersRes.data);
    setProperties(propertiesRes.data);
    setInquiries(inquiriesRes.data);
    setLeads(leadsRes.data);
    setBookings(bookingsRes.data);
  };

  useEffect(() => {
    load();
  }, []);

  const totalCategories = new Set(properties.map((property) => property.propertyType).filter(Boolean)).size;
  const recentUploads = properties.slice(0, 4);

  return (
    <section className="section admin-page">
      <div className="admin-shell">
        <aside className="admin-sidebar">
          <Link className="brand" to="/admin">UrbanNest Admin</Link>
          <nav>
            <Link to="/admin">Dashboard</Link>
            <Link to="/admin/properties">Properties</Link>
            <Link to="/admin/properties/add">Add Property</Link>
            <Link to="/admin/leads">Leads</Link>
            <Link to="/admin/bookings">Bookings</Link>
          </nav>
        </aside>

        <div className="admin-content">
          <div className="section-heading">
            <div>
              <p className="eyebrow">Admin Panel</p>
              <h1>Admin Dashboard</h1>
            </div>
            <div className="actions">
              <Link className="btn-outline" to="/admin/properties">Manage Properties</Link>
              <Link className="btn" to="/admin/properties/add">Add Property</Link>
            </div>
          </div>

          <div className="stats-grid admin-stat-grid">
            <div><strong>{properties.length || stats.properties}</strong><p>Total Properties</p></div>
            <div><strong>{totalCategories}</strong><p>Total Categories</p></div>
            <div><strong>{recentUploads.length}</strong><p>Recent Uploads</p></div>
            <div><strong>{bookings.length}</strong><p>Bookings</p></div>
          </div>

          <h2>Recent Uploads</h2>
          <div className="table-list admin-recent-list">
            {recentUploads.map((property) => (
              <div key={property._id}>
                <strong>{property.title}</strong>
                <span>{property.location}</span>
                <span>{formatPrice(property.price)}</span>
              </div>
            ))}
            {!recentUploads.length && <p className="empty-state">No recent uploads yet.</p>}
          </div>

          <h2>Booking History</h2>
          <div className="table-list">
            {bookings.slice(0, 4).map((booking) => (
              <div key={booking._id}>
                <strong>{booking.customerName}</strong>
                <span>{booking.propertyId?.title || 'Property'}</span>
                <span className={`status-pill status-${booking.status.toLowerCase()}`}>{booking.status}</span>
              </div>
            ))}
          </div>

          <h2>Lead Status Tracking</h2>
          <div className="table-list">
            {leads.slice(0, 4).map((lead) => (
              <div key={lead._id}>
                <strong>{lead.fullName}</strong>
                <span>{lead.email}</span>
                <span className={`status-pill status-${lead.status.toLowerCase().replace('-', '')}`}>{lead.status}</span>
              </div>
            ))}
          </div>

          <h2>Manage Users</h2>
          <div className="table-list">
            {users.slice(0, 5).map((user) => <div key={user._id}><strong>{user.name}</strong><span>{user.email}</span><span>{user.role}</span></div>)}
          </div>

          <h2>View Inquiries</h2>
          <div className="table-list">
            {inquiries.slice(0, 5).map((inquiry) => (
              <div key={inquiry._id}>
                <strong>{inquiry.name || inquiry.userId?.name || 'Visitor'}</strong>
                <span>{inquiry.propertyId?.title || 'General Contact'}</span>
                <p>{inquiry.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export default AdminDashboard;
